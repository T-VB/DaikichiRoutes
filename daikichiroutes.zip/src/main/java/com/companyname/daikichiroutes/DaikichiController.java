package com.companyname.daikichiroutes;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
//ctrl + shift + o --> imports all dependencies^ (see above: requestmapping, restcontroller)

@RestController
@RequestMapping("/daikichi")
public class DaikichiController { 
        @RequestMapping("")
        public String index() {
                return "Welcome, weary traveller!";
        }
        @RequestMapping("/today")
        public String today() {
                return "Today you will attempt something new";
        }
        //Explicit route calling example:
        //@RequestMapping(value = "/today", method = RequestMethod.GET)
        //public String today() {
            //return "Today you will attempt something new";
        //}
        @RequestMapping("/tomorrow")
        public String tomorrow() {
                return "Tomorrow will bring you great fortune";
        }
	
}
